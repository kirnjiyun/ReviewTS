import React, { useState } from "react";
import Todo from "./Todo";

// interface TodoProps {
//   id: number;
//   content: string;
//   done: boolean;
// }

function App() {
    // const [todoList, setTodoList] = useState<TodoProps[]>([]);
    return (
        <>
            <Todo />
        </>
    );
}

export default App;
