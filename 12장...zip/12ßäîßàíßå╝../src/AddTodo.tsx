import React, { useState } from 'react';

interface AddTodoProps {
  todoList: { id: number; content: string; done: boolean }[];
  setTodoList: React.Dispatch<
    React.SetStateAction<{ id: number; content: string; done: boolean }[]>
  >;
  idCount: number;
  setIdCount: React.Dispatch<React.SetStateAction<number>>;
}

const AddTodo: React.FC<AddTodoProps> = ({ setTodoList, idCount, setIdCount }) => {
  const [inputValue, setInputValue] = useState('');

  const onAddTodo = () => {
    setTodoList((prevTodoList) => [
      ...prevTodoList,
      { id: idCount, content: inputValue, done: false },
    ]);
    setIdCount((prevIdCount) => prevIdCount + 1);
  };

  return (
    <div>
      <input type='text' value={inputValue} onChange={(e) => setInputValue(e.target.value)} />
      <button onClick={onAddTodo}>Add Todo</button>
    </div>
  );
};

export default AddTodo;
